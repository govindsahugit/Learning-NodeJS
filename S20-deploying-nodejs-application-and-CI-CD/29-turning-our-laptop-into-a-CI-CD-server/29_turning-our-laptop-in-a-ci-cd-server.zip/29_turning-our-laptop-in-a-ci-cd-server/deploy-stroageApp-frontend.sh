set -e

PROJECT_DIR="/c/Users/anura/OneDrive/Desktop/web-dev/nodejs-course/section-20/storageApp-frontend"

cd "$PROJECT_DIR"
git pull

echo "Installing client dependencies (npm ci)..."
npm ci --no-audit --no-fund

npm run test
npm run build
echo "Uploading build files to S3 bucket"

aws s3 sync "$PROJECT_DIR/dist" s3://storageapp-frontend --delete
aws cloudfront create-invalidation --distribution-id E3GKKIA9RCN7AF --paths "//index.html"

echo "Frontend Deployed Successfully..."