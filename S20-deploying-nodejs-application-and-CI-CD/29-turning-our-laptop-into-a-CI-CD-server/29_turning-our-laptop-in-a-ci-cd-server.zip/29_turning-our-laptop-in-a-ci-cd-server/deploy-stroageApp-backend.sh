ssh storageApp 'bash' << 'EOF'
    set -e

    cd /home/ubuntu/stroageApp-backend
    git pull
    echo "Installing client dependencies (npm ci)..."
    npm ci --no-audit --no-fund
    pm2 reload storageApp

    echo "Backend Deployed Successfully..."
EOF