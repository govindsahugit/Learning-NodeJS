import "dotenv/config";
import express from "express";
import { spawn } from "child_process";
import crypto from "crypto";

const PORT = process.env.PORT || 4000;

const app = express();
app.use(express.json());

app.post("/github-webhook", (req, res) => {
  const givenSignature = req.headers["x-hub-signature-256"];
  if (!givenSignature) {
    return res.status(403).json({ error: "Invalid Signature" });
  }
  const calculatedSignature =
    "sha256=" +
    crypto
      .createHmac("sha256", process.env.GITHUB_SECRET)
      .update(JSON.stringify(req.body))
      .digest("hex");

  if (givenSignature !== calculatedSignature) {
    return res.status(403).json({ error: "Invalid Signature" });
  }

  res.json({ message: "OK" });

  let repository = req.body.repository.name
  
  console.log({ repository });

  const bashChildProcess = spawn("bash", [`./deploy-${repository}.sh`]);

  bashChildProcess.stdout.on("data", (data) => {
    process.stdout.write(data);
  });

  bashChildProcess.stderr.on("data", (data) => {
    process.stderr.write(data);
  });

  bashChildProcess.on("close", (code) => {
    if (code === 0) {
      console.log("Script executed successfully!");
    } else {
      console.log("Script failed!");
    }
  });

  bashChildProcess.on("error", (err) => {
    console.log("Error in spawning the process!");
    console.log(err);
  });
});

app.listen(PORT, () => {
  console.log(`Server Started`);
});
